from file_handler import FileHandler

def main():
    print("-----: MedixPlus :-----")
    medicines = FileHandler.load_medicines("medicine.csv")
    
    while True:
        print()    
        print("1. Add Medicine")
        print("2. Display Medicine Details")
        print("3. Shop Medicine")
        print("4. Update Medicine Stock & Price")
        print("5. Search Medicine")
        print("6. Delete Medicine")
        print("7. Save and Exit")
        
        choice = int(input("Enter your choice: "))
        
        if choice == 1:
            FileHandler.add_medicine(medicines)
        elif choice == 2:
            FileHandler.display_medicine(medicines)
        elif choice == 3:
            FileHandler.shop_medicine(medicines)
        elif choice == 4:
            FileHandler.update_medicine(medicines)
        elif choice == 5:
            FileHandler.find_medicine(medicines)
        elif choice == 6:
            FileHandler.delete_medicine(medicines)
        elif choice == 7:
            FileHandler.save_medicine(medicines)
            print("Exiting...")
            break
        else:
            print("Invalid choice. Select from menu.")
         
if __name__ == "__main__":
    main()