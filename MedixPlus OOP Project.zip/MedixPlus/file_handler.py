import csv
from medicine import Medicine
from solid_med import SolidMedicine
from liquid_med import LiquidMedicine
from topical_med import TopicalMedicines

class FileHandler:
    @staticmethod
    def save_medicine(medicines):
        with open("medicine.csv", mode="w", newline="") as file:
            writer = csv.writer(file)
            writer.writerow(["Name", "Price", "Stock Quantity", "Type", "Category", "Dosage mg", "Quantity ml"])
            for med in medicines:
                if isinstance(med, SolidMedicine):
                    writer.writerow([med.name, med.price, med.get_stock_quantity(), med.get_type_medicine(), "", med.get_dosage(), ""])
                elif isinstance(med, LiquidMedicine):
                    writer.writerow([med.name, med.price, med.get_stock_quantity(), med.get_type_medicine(), "", "", med.get_quantity()])
                elif isinstance(med, TopicalMedicines):
                    writer.writerow([med.name, med.price, med.get_stock_quantity(), "", med.get_category(), "", ""])
                else:
                    writer.writerow([med.name, med.price, med.get_stock_quantity(), "", "", "", ""])

    @staticmethod
    def load_medicines(filename):
        medicines = []
        try:
            with open("medicine.csv", mode="r") as file:
                reader = csv.DictReader(file)
                for row in reader:
                    if row["Dosage mg"]:
                        medicines.append(SolidMedicine(row["Name"], float(row["Price"]), int(row["Stock Quantity"]), row["Type"], row["Dosage mg"]))
                    elif row["Quantity ml"]:
                        medicines.append(LiquidMedicine(row["Name"], float(row["Price"]), int(row["Stock Quantity"]), row["Type"], row["Quantity ml"]))
                    elif row["Category"]:
                        medicines.append(TopicalMedicines(row["Name"], float(row["Price"]), int(row["Stock Quantity"]), row["Category"]))
                    else:
                        medicines.append(Medicine(row["Name"], float(row["Price"]), int(row["Stock Quantity"])))
        except FileNotFoundError:
            print("File 'medicine.csv' not found. Starting with an empty list.")
        return medicines

    @staticmethod
    def add_medicine(medicines):
        medicine_type = input("Enter new medicine: \n1. Ingestible Drugs \n2. Topical Medicines \n3. Other \n").strip()
        name = input("Enter name:").strip().title()
        price = int(input("Enter price:"))
        stock_quantity = int(input("Enter stock quantity:"))
        if medicine_type == "1":
            type_medicine = input("Enter medicine type Syrup/Tablet/Capsule:").strip().title()
            
            if type_medicine == "Tablet" or type_medicine == "Capsule":
                dosage_mg = float(input("Enter dosage in mg:"))
                medicines.append(SolidMedicine(name, price, stock_quantity, type_medicine, dosage_mg))
                
            elif type_medicine == "Syrup":
                dosage_ml = float(input("Enter dosage in ml:"))
                medicines.append(LiquidMedicine(name, price, stock_quantity, type_medicine, dosage_ml))
                
        elif medicine_type == "2":
            category = input("Enter category:").title()
            medicines.append(TopicalMedicines(name, price, stock_quantity, category))

        else:
            medicines.append(Medicine(name, price, stock_quantity))

        print(f"{name} successfully added.")
        
    @staticmethod
    def display_medicine(medicines):
        print("---: Medicines Stock Details :---")
        for med in medicines:
            med.display_info()
            print('-' * 30)

    @staticmethod
    def shop_medicine(medicines):
        name = input("\nEnter the name of the medicine to shop: ").strip().lower()
        for med in medicines:
            if med.name.lower() == name:
                stock_quantity = med.get_stock_quantity()
                if stock_quantity <= 0:
                    print(f"{med.name} is out of stock!")
                    return
                
                required_quantity = int(input(f"Enter the quantity required (Available: {stock_quantity}): "))
                if required_quantity <= stock_quantity:
                    total_price = required_quantity * med.price
                    med.set_stock_quantity(stock_quantity - required_quantity)
                    print("-------: MedixPlus :-------")
                    print(f"Medicine: {med.name}")
                    print(f"Quantity Taken: {required_quantity}")
                    print(f"Price Per Unit: {med.price}")
                    print(f"Total Price: {total_price}")
                    print('-' * 27)
                else:
                    print(f"Insufficient stock! Only {stock_quantity} units available.")
                return
        print(f"{name.title()} not found!")

    @staticmethod
    def update_medicine(medicines):
        name = input("\nEnter the name of the medicine to update: ").strip().lower()
        for med in medicines:
            if med.name.lower() == name:
                new_price = float(input("Enter the new price: "))
                additional_stock = int(input("Enter the additional stock quantity to add: "))
                med.price = new_price
                med.set_stock_quantity(med.get_stock_quantity() + additional_stock)
                print(f"{med.name} has been updated successfully!")
                return
        print(f"Medicine '{name.title()}' not found!")

    @staticmethod
    def find_medicine(medicines):
        name = input("\nEnter the name of the medicine to search: ").strip().lower()
        for med in medicines:
            if med.name.lower() == name:
                print("Medicine found! Details are as follows:")
                med.display_info()
                return
        print(f"Medicine '{name.title()}' not found!")

    @staticmethod
    def delete_medicine(medicines):
        name = input("\nEnter the name of the medecine to delete: ").strip().lower()
        for med in medicines:
            if med.name.lower() == name:
                medicines.remove(med)
                print(f"{med.name} info deleted successfully!")
                return
        print(f"{name.title()} not found!")
