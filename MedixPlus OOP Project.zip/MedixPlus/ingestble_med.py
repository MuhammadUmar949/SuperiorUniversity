from medicine import Medicine

class IngestibleMedicines(Medicine):
    def __init__(self, name, price, stock_quantity, type_medicine):
        super().__init__(name, price, stock_quantity)
        self.__type_medicine = type_medicine

    def display_info(self):
        super().display_info()
        print(f"Type:           {self.__type_medicine}")

    def get_type_medicine(self):
        return self.__type_medicine

    def set_type_medicine(self, type_medicine):
        self.__type_medicine = type_medicine
