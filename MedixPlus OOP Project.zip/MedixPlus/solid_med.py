from ingestble_med import IngestibleMedicines

class SolidMedicine(IngestibleMedicines):
    def __init__(self, name, price, stock_quantity, type_medicine, dosage):
        super().__init__(name, price, stock_quantity, type_medicine)
        self.__dosage = dosage

    def display_info(self):
        super().display_info()
        print(f"Dosage:         {self.__dosage}mg")

    def get_dosage(self):
        return self.__dosage

    def set_dosage(self, dosage):
        self.__dosage = dosage
