class Medicine:
    def __init__(self, name, price, stock_quantity):
        self.name = name
        self.price = price
        self.__stock_quantity = stock_quantity

    def display_info(self):
        print(f"Name:           {self.name}")
        print(f"Price:          {self.price} PKR")
        print(f"Stock Quantity: {self.__stock_quantity}")

    def get_stock_quantity(self):
        return self.__stock_quantity

    def set_stock_quantity(self, stock_quantity):
        self.__stock_quantity = stock_quantity
