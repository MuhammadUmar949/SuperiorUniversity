from medicine import Medicine

class TopicalMedicines(Medicine):
    def __init__(self, name, price, stock_quantity, category):
        super().__init__(name, price, stock_quantity)
        self.__category = category

    def display_info(self):
        super().display_info()
        print(f"Category:       {self.__category}")

    def get_category(self):
        return self.__category

    def set_category(self, category):  
        self.__category = category