from ingestble_med import IngestibleMedicines

class LiquidMedicine(IngestibleMedicines):
    def __init__(self, name, price, stock_quantity, type_medicine, quantity):
        super().__init__(name, price, stock_quantity, type_medicine)
        self.__quantity = quantity

    def display_info(self):
        super().display_info()
        print(f"Quantity:       {self.__quantity}ml")

    def get_quantity(self):
        return self.__quantity

    def set_quantity(self, quantity):
        self.__quantity = quantity
